/*
 * Solutions to Assignment 2 for CPSC 5000
 */
package assignmenttwo;

/**
 *
 * @author jfuqua390
 */
public class AssignmentTwo {
    public static void main(String[] args) {
        //Can just run through each problem by executing main
        numberOne.main();
        numberTwo.main();
        numberThree.main();
        numberFour.main();
    }
    
}
