/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package final2018;

/**
 *
 * @author jfuqua390
 */
public class numberTwoTest {
    public static void main() {
        Executive Jon = new Executive("Jon", 50000, "Marketing", "CMO");
        System.out.println(Jon.toString());
    }
}
